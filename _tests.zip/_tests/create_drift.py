import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def simulate_drift(x, y, z, drift_rate=0.1):
    """
    Simulate drift in a trajectory.
    
    Args:
    x, y, z (np.array): Original x, y, z coordinates of the trajectory.
    drift_rate (float): The rate at which drift increases per time step.
    
    Returns:
    np.array: x, y, z coordinates with simulated drift.
    """
    # Initialize arrays to store the drifted coordinates
    x_drifted = np.zeros_like(x)
    y_drifted = np.zeros_like(y)
    z_drifted = np.zeros_like(z)
    
    # Initialize drift amounts
    drift_x = 0
    drift_y = 0
    drift_z = 0
    
    # Apply increasing drift to each point
    for i in range(len(x)):
        x_drifted[i] = x[i] + drift_x
        y_drifted[i] = y[i] + drift_y
        z_drifted[i] = z[i] + drift_z
        
        # Increase the drift by the drift rate
        drift_x += drift_rate * 2.5
        drift_y += drift_rate * 1.5  # Different rates for y, z for example
        drift_z += drift_rate * 0.2

    return x_drifted, y_drifted, z_drifted

def save_trajectory_to_file(x, y, z, file_path):
    """
    Save the trajectory points to a file with each line in the format:
    0 0 0 x 0 0 0 y 0 0 0 z
    
    Args:
    x, y, z (np.array): x, y, z coordinates of the trajectory.
    file_path (str): Path to the file where the trajectory will be saved.
    """
    # Create a matrix where each line corresponds to '0 0 0 x 0 0 0 y 0 0 0 z'
    data_to_save = np.zeros((len(x), 12))
    data_to_save[:, 3] = x
    data_to_save[:, 7] = y
    data_to_save[:, 11] = z
    
    # Save the matrix to a file
    np.savetxt(file_path, data_to_save, fmt='%f')

def plot_trajectory(gt_path, file_path):
    '''
    file_path: Path to gt file.
    step: Interval at which to plot the camera frustums.
    scale: Scale of the camera frustums.
    '''

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Load and reshape the data to a list of 4x4 matrices
    data = np.loadtxt(gt_path).reshape(-1, 3, 4)
    # Extract the x, y, z coordinates
    x = np.array(data[:, 0, 3])
    y = np.array(data[:, 1, 3])
    z = np.array(data[:, 2, 3])

    # Plotting
    ax.plot(x, y, z, label='GT')

    drift = 0.01

    xs, ys, zs = simulate_drift(x,y,z)
    # Plotting
    ax.plot(xs, ys, zs, label='Simulated')   

        
    # Set all three axis limits to the minimum size
    # min_limit = min(min(x), min(y), min(z))
    # max_limit = max(max(x), max(y), max(z))
    # ax.set_xlim(min_limit, max_limit)
    # ax.set_ylim(min_limit, max_limit)
    # ax.set_zlim(min_limit, max_limit)

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.legend()
    plt.show()

    save_trajectory_to_file(xs, ys, zs, file_path)


plot_trajectory(gt_path = '_tests/dataset/poses/03.txt',
                file_path = '_tests/dataset/simulated_drift/03_2.txt')