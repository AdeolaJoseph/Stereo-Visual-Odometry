https://github.com/MichaelGrupp/evo


evo_traj kitti _tests/dataset/simulated_drift/01.txt --ref=_tests/dataset/poses/01.txt -p --plot_mode=xyz
