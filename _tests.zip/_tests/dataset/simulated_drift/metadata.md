# 01

drift rate: 0.02
d_y = 1.5
d_z = 0.2