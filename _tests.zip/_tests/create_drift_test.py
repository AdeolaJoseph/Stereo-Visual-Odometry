from plot_poses import plot_trajectory


plot_trajectory(gt_path = '_tests/dataset/poses/01.txt', 
                estimated_path = '_tests/dataset/simulated_drift/01.txt',
                draw_viewframes = False)